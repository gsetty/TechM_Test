package com.techm.ms.exception;

public class UserCreateException extends Exception {
	
	private CustomError customError;

	public UserCreateException(CustomError error) {
		this.customError = error;
	}
	public CustomError getCustomError() {
		return customError;
	}

	public void setCustomError(CustomError customError) {
		this.customError = customError;
	}
	
}
